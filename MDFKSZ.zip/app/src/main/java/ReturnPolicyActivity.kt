package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ReturnPolicyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_return_policy)

        // Displaying return policy instructions in a TextView
        val returnPolicyText = findViewById<TextView>(R.id.returnPolicyText)
        returnPolicyText.text = """
            Follow these simple steps to return your parcel via UPS:

            1. Get Your Parcel Ready
            - First things first – you need to pack your items in a sturdy box. If you don’t have one, you can order supplies online.
            - Seal your box with plastic or nylon tape at least 3 centimeters wide. Don’t use duct tape.
            - Wrap items separately and use cushioning material.
            - You’ll need to know the dimensions and weight of your box.

            2. Get a Return Label
            - It’s easy to make a label online, too. You can:
            - Choose how fast you want your parcel to arrive.
            - See how much it will cost.
            - Pay by card or PayPal, or pay in store at a UPS Customer Counter.

            3. Get It to UPS
            - Almost done! You’ve got two options to get it to UPS:
            - We can come to you (for an additional fee) – Schedule a collection.
            - Drop it off at a UPS location.
        """.trimIndent()

        // Set up the Back button to navigate back to TruckingVendor activity
        val backButton = findViewById<Button>(R.id.backButton)
        backButton.setOnClickListener {
            // Navigate back to TruckingVendor activity
            val intent = Intent(this, truckingvendor::class.java)
            startActivity(intent)
            finish()  // Close the current activity
        }
    }
}
